import javax.swing.*;

public class MenuItem {
	String emri;
	double qmimi;

	public MenuItem(String emri, double qmimi) {
		this.emri = emri;
		this.qmimi = qmimi;
	}

   

}
