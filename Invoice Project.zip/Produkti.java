import javax.swing.*;

public class Produkti {

	private double qmimi;
	private int sasia;
	private String emriProduktit;

	public Produkti(double qmimi, int sasia, String emriProduktit) {
		this.qmimi = qmimi;
		this.sasia = sasia;
		this.emriProduktit = emriProduktit;
	}

	public double getQmimi() {
		return qmimi;
	}

	public int getSasia() {
		return sasia;
	}
	public String getEmriProduktit() {
		return emriProduktit;
	}
}