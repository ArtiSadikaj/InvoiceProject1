import javax.swing.*;

public class Faktura {
	private Produkti[] produktet;
	private int index = 0;// kjo na nevojitet me kqyr sa po mushet
	private double qmimiFaktures;

	public Faktura(int numriProdukteve) {
		produktet = new Produkti[numriProdukteve];
	}

	public boolean ekziston(Produkti p) {
		for (int i = 0; i < index; i++) {
			if (produktet[i].equals(p)) {
				return true;
			}
		}
		return false;
	}

	public void shtoProduktin(Produkti p) {
		if (p == null) {
			return;// veq me mshel metoden jo me vazhdu
		}
		if (index == produktet.length) {
			return;// ska vend
		}
		if (ekziston(p)) {
			return;// nese nuk ekziston ska nevoje me shtu
		}
		produktet[index++] = p;
		qmimiFaktures += p.getQmimi() * p.getSasia();
	}

	
	public double qmimiFakturs(){
		return qmimiFaktures;
	}

}
