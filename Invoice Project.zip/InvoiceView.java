import java.awt.*;
import javax.swing.*;

public class InvoiceView extends JPanel {

	private String emri, mbiemri, adresa, emaila;
   private int shemimi=4;
	private String[] shenimet = new String[shemimi];
	private double qmimi1 = 3.0;
	private double qmimi2 = 1.50;
	private double qmimi3 = 1.80;
	private double qmimi4 = 0.70;
	private double qmimi5 = 0.50;
	
	private double totali = 0;

	private String pizza = "Pica";
	private String hamburger = "Hamburger";
	private String sandwich = "Sandwich";
	private String hotdog = "Hotdog";
	private String toast = "Toast";
   
	private InvoiceController v = new InvoiceController();
	
	private int w1 = 0;
	private int w2 = 0;
	private int w3 = 0;
	private int w4 = 0;
	private int w5 = 0;
   
	private int hyrja;

	private int sa_porosi = 5;
	private MenuItem[] menu = new MenuItem[sa_porosi];

	public InvoiceView() {

		shenimet[0] = JOptionPane.showInputDialog("Shkruaj emrin");

		shenimet[1] = JOptionPane.showInputDialog("Shkruaj mbiemrin");

		shenimet[2] = JOptionPane.showInputDialog("Shkruaj adresen");

		shenimet[3] = JOptionPane.showInputDialog("Shkruaj emailin");

		emri = "Emri: " + shenimet[0];
		mbiemri = "Mbiemri: " + shenimet[1];
		adresa = "Adresa: " + shenimet[2];
		emaila = "Emaila:" + shenimet[3];

		boolean ok = true;
		while (ok) {

			String a = JOptionPane.showInputDialog("\t Porosit \"Pica\"(3.0) --duke klikuar 0"
					+ "\n Porosit \"Hamburger\"(1.50) --duke klikuar 1" + "\n Porosit \"Sandwich\"(1.80) --duke klikuar 2"
					+ "\n Porosit \"Hotdog\"(0.70) --duke klikuar 3" + "\n Porosit \"Toast\"(0.50) --duke klikuar 4"+
               "\n Nese nuk deshiron asgje per te porositur,shtyp nje numer qe nuk perfshin nr.(0,1,2,3,4)");
         if(a==null || a.equals(""))
         {JOptionPane.showMessageDialog(null,"Keni prekur gabimisht njeren nga opcionet \"ok\" ose \"cancel\",shkruaje nje numer.");}
         
          else{
			hyrja = new Integer(a).intValue();
			
			switch (hyrja) {
         
			case 0: {

				menu[0] = new MenuItem(pizza, qmimi1);
				w1++;
				break;
			}
			case 1: {
				menu[1] = new MenuItem(hamburger, qmimi2);
				w2++;
				break;
			}
			case 2: {
				menu[2] = new MenuItem(sandwich, qmimi3);
				w3++;
				break;
			}
			case 3: {
				menu[3] = new MenuItem(hotdog, qmimi4);
				w4++;
				break;
			}
			case 4: {
				menu[4] = new MenuItem(toast, qmimi5);
				w5++;
				break;
			}

			}
   }
			if (hyrja >= 0 && hyrja < menu.length) 
         {}
			else {ok = false;}
         
			if (hyrja == 0) {
				totali += w1 *qmimi1;
			}
			if (hyrja == 1) {
				totali += w2 *qmimi2;
			}
			if (hyrja == 2) {
				totali += w3 *qmimi3;
			}
			if (hyrja == 3) {
				totali += w4 *qmimi4;
			}
			if (hyrja == 4) {
				totali += w5 *qmimi5;
			}else{}

		}
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		repaint();
		g.setColor(Color.black);
		g.drawString("SHENIMET PERSONALE", 25, 60);
		g.setColor(Color.gray);
		g.drawRect(20, 70, 200, 150);
		g.fillRect(20, 70, 200, 150);
		g.setColor(Color.blue);
		   g.drawString(emri, 30, 80);
		g.setColor(Color.blue);
		   g.drawString(mbiemri, 30, 100);
		g.setColor(Color.blue);
   		g.drawString(adresa, 30, 120);
		g.setColor(Color.blue);
		   g.drawString(emaila, 30, 140);
		g.setColor(Color.black);
		g.drawString("MENYJA", 380, 60);
		g.setColor(Color.blue);
		g.setColor(Color.gray);
		g.drawRect(350, 70, 120, 250);
		g.fillRect(350, 70, 120, 250);
		
		g.setColor(Color.blue);
		g.drawString(pizza+":"+w1, 350, 80);
		g.drawString(hamburger+":"+w2, 350, 100);
		g.drawString(sandwich+":"+w3, 350, 120);
		g.drawString(hotdog+":"+w4, 350, 140);
		g.drawString(toast+":"+w5, 350, 160);
      
		g.drawString(v.coca()+":"+v.sasia1(), 350, 180);
      g.drawString(v.tango()+":"+v.sasia2(), 350, 200);
      g.drawString(v.fanta()+":"+v.sasia3(), 350, 220);
		g.drawString(v.sprite()+":"+v.sasia4(), 350, 240);
		
	   g.setColor(Color.black);
		g.drawString("TOTALI", 250, 490);
		g.setColor(Color.gray);
		g.drawRect(200, 500, 250, 100);
		g.fillRect(200, 500, 250, 100);
      g.setColor(Color.blue);		
		g.drawString("Totali i ushqimit: "+totali+" euro.", 200, 520);
		g.drawString("Totali i pijeve: "+v.faktura()+" euro", 200, 540);
      g.setColor(Color.black);
		g.drawString("TOTALI: "+(v.faktura()+totali)+" euro", 200, 580);
	}
}