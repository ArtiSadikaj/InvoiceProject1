import javax.swing.*;
import java.awt.*;

public class InvoiceController extends JPanel {
	private static  String coca = "Coca";
   private static  String tango = "Tango";
   private static  String fanta = "Fanta";
	private static  String sprite = "Sprite";
	
   
	private static  double qmimi1=1.0;   //Qmimi i Coca-coles=1 euro.
	private static  double qmimi2=1.50;   //Qmimi i Tangos=1.50 euro.
	private static  double qmimi3=0.70;   //Qmimi i Fantes=0.70 euro.
	private static  double qmimi4=1.20;   //Qmimi i Sprite=1.2 euro.
	
	private static int sasia1=0;
	private static int sasia2=0;
	private static int sasia3=0;
	private static int sasia4=0;
	
	private static Faktura f= new Faktura(4); ;
	private static int h;
	
	public static void main(String[] args)

	{
		InvoiceView u = new InvoiceView();
      
		JFrame korniza1 = new JFrame();
		korniza1.setVisible(true);
		korniza1.setSize(500, 700);
		korniza1.setTitle("Faktura");
		korniza1.getContentPane().add(u);
      
		
      boolean ok=true;
      while(ok){
		String a = JOptionPane.showInputDialog("\t Porosit \"Coca\"(1.0) --duke klikuar 0" + "\n Porosit \"Tango\"(1.50) --duke klikuar 1"
						+ "\n Porosit \"Fanta\"(0.70) --duke klikuar 2" + "\n Porosit \"Sprite\"(1.20) --duke klikuar 3"+
                  "\n Nese nuk deshiron asgje per te porositur,shtyp nje numer qe nuk perfshin nr.(0,1,2,3)");
                   if(a==null || a.equals("")){
		JOptionPane.showMessageDialog(null,"Keni prekur gabimisht njeren nga opcionet \"ok\" ose \"cancel\",shkruaje nje numer.");
       
       }
     
      else{
         h = new Integer(a).intValue();
		switch (h) {
		case 0: {
			int hyrja = new Integer(JOptionPane.showInputDialog("Shkruaje numrin e sasise te Coca-coles")).intValue();
			if (hyrja < 0) {
				JOptionPane.showMessageDialog(null, "Keni shkruar gabim numrin e sasise " + hyrja);
			} else {
				Produkti p1 = new Produkti(qmimi1, hyrja, coca);
				f.shtoProduktin(p1);
				sasia1+=hyrja;
			}
			break;
		}

		case 1: {
			int hyrja1 = new Integer(JOptionPane.showInputDialog("Shkruaje numrin e sasise te Tango")).intValue();
			if (hyrja1 < 0) {
				JOptionPane.showMessageDialog(null, "Keni shkruar gabim numrin e sasise " + hyrja1);
			} else {
				Produkti p2 = new Produkti(qmimi2, hyrja1, sprite);
				f.shtoProduktin(p2);
				sasia2+=hyrja1;
			}
			break;
		}

		case 2: {
			int hyrja2 = new Integer(JOptionPane.showInputDialog("Shkruaje numrin e sasise te Fanta")).intValue();
			if (hyrja2 < 0) {
				JOptionPane.showMessageDialog(null, "Keni shkruar gabim numrin e sasise " + hyrja2);
			} else {
				Produkti p3 = new Produkti(qmimi3, hyrja2, tango);
				f.shtoProduktin(p3);
				sasia3+=hyrja2;
			}
			break;
		}

		case 3: {
			int hyrja3 = new Integer(JOptionPane.showInputDialog("Shkruaje numrin e sasise te Sprite")).intValue();
			if (hyrja3 < 0) {
				JOptionPane.showMessageDialog(null, "Keni shkruar gabim numrin e sasise " + hyrja3);
			} else {
				Produkti p4 = new Produkti(qmimi4, hyrja3, fanta);
				f.shtoProduktin(p4);
            sasia4+=hyrja3;
			}

			break;
		}
		default: {
			
		}

		}
      }
      
      if (h >= 0 && h < 4) {
			}

			else {
				ok = false;
			}
		}
		korniza1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		korniza1.repaint();
   }

	public String coca(){
		return coca;
	}
   public String tango(){
		return tango;
	}
   
	public String fanta(){
		return fanta;
	}
	public String sprite(){
		return sprite;
	}
	
	public double qmimi1(){
		return qmimi1;
		
	}
	public double qmimi2(){
		return qmimi2;
		
	}
	public double qmimi3(){
		return qmimi3;
		
	}
	public double qmimi4(){
		return qmimi4;
		
	}
	public int sasia1(){
		return sasia1;
	}
	public int sasia2(){
		return sasia2;
	}
	public int sasia3(){
		return sasia3;
	}
	public int sasia4(){
		return sasia4;
	}
	public double faktura(){
		return f.qmimiFakturs();
	}
}